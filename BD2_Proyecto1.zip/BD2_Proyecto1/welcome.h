    #ifndef WELCOME_H
#define WELCOME_H

#include <QMainWindow>
#include <QtMultimedia>
#include <QtMultimediaWidgets>
#include <QtCore>
#include <QtGui>
#include <QtWidgets>

QT_BEGIN_NAMESPACE
namespace Ui {
class Welcome;
}
QT_END_NAMESPACE

class Welcome : public QMainWindow
{
    Q_OBJECT;
    QMediaPlayer *player;

public:
    Welcome(QWidget *parent = nullptr);
    ~Welcome();
    void keyPressEvent(QKeyEvent *event);

private slots:
    void on_pushButton_clicked();
    void on_enviar1_clicked();
    void loadCSV();
    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::Welcome *ui;

};
#endif // WELCOME_H
