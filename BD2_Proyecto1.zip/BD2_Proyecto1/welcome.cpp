#include "welcome.h"
#include "ui_welcome.h"
#include "qdebug.h"
#include "Sequential_file.h"
#include <QFile>
#include <QTextStream>
#include <string>
#include <parsersql.h>
#include <QMessageBox>
#include <QFileDialog>

const int64_t MAX_RECORDS = 1000;



void visualizar_generar_bin(bool visualizar = false){
    records_csv_to_bin("movie_dataset.csv");
    // ++++++++++Manejo de movie_dataset.bin++++++++++++
    ifstream movie_bin(data_path+"movie_dataset.bin", ios::binary);
    if(!movie_bin.is_open()) throw runtime_error("Error al abrir el archivo");

    movie_bin.seekg(0, ios::end);
    cout<<"------------------------------------------\n";
    cout<<"Cantidad de registros en .bin: "<<movie_bin.tellg()/sizeof(Record)<<endl;
    cout<<"------------------------------------------\n"<<endl;

    if(visualizar){
        cout<<"---------------------------------------------Visualización de registros---------------------------------------------\n";
        movie_bin.seekg(0, ios::beg);
        Record record;
        while(movie_bin.read(reinterpret_cast<char*>(&record), sizeof(Record))){
            record.showData_line();
        }
        cout<<"---------------------------------------------Visualización de registros---------------------------------------------\n";
    }

    movie_bin.close();
    // +++++++++++++++++++++++++++++++++++++++++++++++++
}
Welcome::Welcome(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Welcome)
{
    ui->setupUi(this);


    QVBoxLayout *layout = new QVBoxLayout(ui->widget);

    QVideoWidget *videoWidget = new QVideoWidget();

    layout->addWidget(videoWidget);

    player = new QMediaPlayer();
    player->setVideoOutput(videoWidget);

        player->setSource(QUrl::fromLocalFile("C:/Users/esteb/Downloads/5157555-uhd_4096_2160_25fps.mp4"));
        videoWidget->show();
        player->play();

    connect(ui->enviar2, &QPushButton::clicked, this, &Welcome::loadCSV);

}


Welcome::~Welcome()
{
    delete ui;
}

void Welcome::keyPressEvent(QKeyEvent *event){
      if (event->key() == Qt::Key_Enter || event->key() == Qt::Key_Return){
        QString sql = ui->input1->text();
        ui->label_4->setText(sql);
    }

}

void Welcome::on_pushButton_clicked()
{
    player->setPosition(0);
    player->play();
}


void Welcome::on_enviar1_clicked()
{
    QString sql = ui->input1->text();
    ui->label_4->setText(sql);

    //1. Descomentar y generar los registros de .csv a .bin
    try {
        visualizar_generar_bin();

        Sequential_File file("data_sf.bin",1);
        //2. Descomentar para usar leer los registros de .bin
        // ++++++++++Manejo de movie_dataset.bin++++++++++++
        ifstream movie_bin(data_path+"movie_dataset.bin", ios::binary);
        if(!movie_bin.is_open()) throw runtime_error("Error al abrir el archivo");

        Record record;
        Record_SFile record_sf;
        for(int i = 0; i<MAX_RECORDS; i++){
            movie_bin.read(reinterpret_cast<char*>(&record), sizeof(Record));
            record_sf = Record_SFile(record);
            file.add(record_sf);
        }
        movie_bin.close();
        // // +++++++++++++++++++++++++++++++++++++++++++++++++
        // 3. Visualización de archivos
        cout<<endl;
        file.print_file("data_sf.bin");
        cout<<endl;
        file.print_file("aux_sf.bin");

        cout<<endl<<endl<<endl<<endl<<"hola3";


        // ADVERTENCIA: Si se comentó la sección ADD, cambiar a 0 el segundo parámetro del constructor de Sequential_File
        // 4. Remove record
        if(file.remove_record("9802")) cout<<"Registro eliminado"<<endl;
        if(file.remove_record("11")) cout<<"Registro eliminado"<<endl;
        if(file.remove_record("791373")) cout<<"Registro eliminado"<<endl;



        file.print_file("data_sf.bin");
        cout<<endl;
        file.print_file("aux_sf.bin");
        cout<<endl;

        // 5. Busqueda de registros
        auto vec = file.range_search("23","150");
        for(auto& r: vec){
            r.showData_line();
        }
        cout<<endl;
        // 6. Busqueda de registros
        file.search("99861").showData_line();
        cout<<endl;

    } catch (exception &ex) {
        cout<<ex.what();
    }
}


void Welcome::loadCSV()
{
    QString fileName = QFileDialog::getOpenFileName(this, "Open CSV File", "", "CSV Files (*.csv)");
    if (fileName.isEmpty())
        return;

    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QMessageBox::warning(this, "Error", "Cannot open file: " + file.errorString());
        return;
    }

    // Mostrar el nombre del archivo en el label
    ui->label_5->setText(fileName);

    // Limpiar la tabla antes de cargar nuevos datos
    ui->tableWidget->clear();
    ui->tableWidget->setRowCount(0);
    ui->tableWidget->setColumnCount(0);

    QTextStream in(&file);
    QStringList headers;
    QString firstLine;
    if (!in.atEnd())
    {
        firstLine = in.readLine();
        if (firstLine.contains(";"))
        {
            headers = firstLine.split(";");
        }
        else if (firstLine.contains(","))
        {
            headers = firstLine.split(",");
        }
        else
        {
            QMessageBox::warning(this, "Error", "Unknown delimiter in CSV file");
            file.close();
            return;
        }
        ui->tableWidget->setColumnCount(headers.size());
        ui->tableWidget->setHorizontalHeaderLabels(headers);
    }

    int row = 0;
    while (!in.atEnd())
    {
        QString line = in.readLine();
        QStringList fields;
        if (firstLine.contains(";"))
        {
            fields = line.split(";");
        }
        else if (firstLine.contains(","))
        {
            fields = line.split(",");
        }
        ui->tableWidget->insertRow(row);
        for (int col = 0; col < fields.size(); ++col)
        {
            ui->tableWidget->setItem(row, col, new QTableWidgetItem(fields.at(col)));
        }
        ++row;
    }

    file.close();
}

void Welcome::on_pushButton_2_clicked()
{
    // QString fileName = QFileDialog::getOpenFileName(this, "Open Binary File", "", "Binary Files (*.bin)");
    // if (fileName.isEmpty())
    //     return;
    QString fileName = "C:/Users/esteb/Downloads/movie_dataset.bin";
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::warning(this, "Error", "Cannot open file: " + file.errorString());
        return;
    }

    // Mostrar el nombre del archivo en el label
    ui->label_5->setText(fileName);

    // Limpiar la tabla antes de cargar nuevos datos
    ui->tableWidget->clear();
    ui->tableWidget->setRowCount(0);
    ui->tableWidget->setColumnCount(8);  // Hay 8 campos en el registro
    ui->tableWidget->setHorizontalHeaderLabels({"ID", "Name", "Punt. Promedio", "Vote Count", "Release Date", "Ganancia", "Tiempo", "Lang"});

    QDataStream in(&file);
    in.setByteOrder(QDataStream::LittleEndian);  // Ajustar según sea necesario

    int row = 0;
    while (!in.atEnd())
    {
        Record record;
        in.readRawData(reinterpret_cast<char*>(&record), sizeof(Record));

        ui->tableWidget->insertRow(row);
        ui->tableWidget->setItem(row, 0, new QTableWidgetItem(QString::number(record.id)));
        ui->tableWidget->setItem(row, 1, new QTableWidgetItem(QString(record.name).trimmed()));
        ui->tableWidget->setItem(row, 2, new QTableWidgetItem(QString::number(record.punt_promedio)));
        ui->tableWidget->setItem(row, 3, new QTableWidgetItem(QString::number(record.vote_count)));
        ui->tableWidget->setItem(row, 4, new QTableWidgetItem(QString(record.release_date).trimmed()));
        ui->tableWidget->setItem(row, 5, new QTableWidgetItem(QString::number(record.ganancia)));
        ui->tableWidget->setItem(row, 6, new QTableWidgetItem(QString::number(record.tiempo)));
        ui->tableWidget->setItem(row, 7, new QTableWidgetItem(QString(record.lang).trimmed()));
        ++row;
    }

    file.close();
}


void Welcome::on_pushButton_3_clicked()
{
    QString sql = ui->input1->text();
    string query = sql.toStdString();
    // Test for SELECT

    Parser parser(query);
    vector<Record> records;
    parser.parse(records);


    if(records.empty()){
        QMessageBox::warning(this,"No hay data", "Vacio pipipi");
        return;
    }

    cout << string(120, '-') << endl;
    ui->label_5->setText("Nombre del archivo o fuente de datos");
    for (const Record& record : records)
    {
        cout<<record.id<<endl;
    }

    cout<<"Hola 1"<<endl;
    cout<<"Hola 1"<<endl;
    cout<<"Hola 1"<<endl;
    // Limpiar la tabla antes de cargar nuevos datos
    // ui->tableWidget->clear();
    // ui->tableWidget->setRowCount(0);
    // ui->tableWidget->setColumnCount(8);  // Hay 8 campos en el registro
    // ui->tableWidget->setHorizontalHeaderLabels({"ID", "Name", "Punt. Promedio", "Vote Count", "Release Date", "Ganancia", "Tiempo", "Lang"});

    // // Iterar sobre el vector de records y llenar la tabla
    // int row = 0;


    // for (const Record& record : records)
    // {
    //     ui->tableWidget->insertRow(row);
    //     ui->tableWidget->setItem(row, 0, new QTableWidgetItem(QString::number(record.id)));
    //     ui->tableWidget->setItem(row, 1, new QTableWidgetItem(QString(record.name).trimmed()));
    //     ui->tableWidget->setItem(row, 2, new QTableWidgetItem(QString::number(record.punt_promedio)));
    //     ui->tableWidget->setItem(row, 3, new QTableWidgetItem(QString::number(record.vote_count)));
    //     ui->tableWidget->setItem(row, 4, new QTableWidgetItem(QString(record.release_date).trimmed()));
    //     ui->tableWidget->setItem(row, 5, new QTableWidgetItem(QString::number(record.ganancia)));
    //     ui->tableWidget->setItem(row, 6, new QTableWidgetItem(QString::number(record.tiempo)));
    //     ui->tableWidget->setItem(row, 7, new QTableWidgetItem(QString(record.lang).trimmed()));
    //     ++row;
    // }

    QString fileName = "C:/Users/esteb/Downloads/movie_dataset.bin";
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::warning(this, "Error", "Cannot open file: " + file.errorString());
        return;
    }

    // Mostrar el nombre del archivo en el label
    ui->label_5->setText(fileName);

    // Limpiar la tabla antes de cargar nuevos datos
    ui->tableWidget->clear();
    ui->tableWidget->setRowCount(0);
    ui->tableWidget->setColumnCount(8);  // Hay 8 campos en el registro
    ui->tableWidget->setHorizontalHeaderLabels({"ID", "Name", "Punt. Promedio", "Vote Count", "Release Date", "Ganancia", "Tiempo", "Lang"});

    QDataStream in(&file);
    in.setByteOrder(QDataStream::LittleEndian);  // Ajustar según sea necesario

    int row = 0;
    while (!in.atEnd())
    {
        Record record;
        in.readRawData(reinterpret_cast<char*>(&record), sizeof(Record));

        ui->tableWidget->insertRow(row);
        ui->tableWidget->setItem(row, 0, new QTableWidgetItem(QString::number(record.id)));
        ui->tableWidget->setItem(row, 1, new QTableWidgetItem(QString(record.name).trimmed()));
        ui->tableWidget->setItem(row, 2, new QTableWidgetItem(QString::number(record.punt_promedio)));
        ui->tableWidget->setItem(row, 3, new QTableWidgetItem(QString::number(record.vote_count)));
        ui->tableWidget->setItem(row, 4, new QTableWidgetItem(QString(record.release_date).trimmed()));
        ui->tableWidget->setItem(row, 5, new QTableWidgetItem(QString::number(record.ganancia)));
        ui->tableWidget->setItem(row, 6, new QTableWidgetItem(QString::number(record.tiempo)));
        ui->tableWidget->setItem(row, 7, new QTableWidgetItem(QString(record.lang).trimmed()));
        ++row;
    }

    file.close();

}

